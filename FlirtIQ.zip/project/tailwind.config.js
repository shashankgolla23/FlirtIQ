/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        'space-dark': '#0a0f1c',
        'glass-dark': 'rgba(255, 255, 255, 0.05)',
        'cyan-primary': '#00fff7',
        'purple-primary': '#b84eff',
        'neon-cyan': '#00fff7',
        'neon-purple': '#b84eff',
      },
      animation: {
        'spin-slow': 'spin 3s linear infinite',
        'pulse-glow': 'pulse-glow 2s ease-in-out infinite',
        'float': 'float 6s ease-in-out infinite',
        'gradient-shift': 'gradientShift 15s ease infinite',
      },
      backdropBlur: {
        'xs': '2px',
      },
      backgroundImage: {
        'gradient-radial': 'radial-gradient(var(--tw-gradient-stops))',
        'gradient-conic': 'conic-gradient(from 180deg at 50% 50%, var(--tw-gradient-stops))',
        'space-gradient': 'radial-gradient(ellipse at center, #1a1a2e 0%, #0a0f1c 100%)',
      },
      fontFamily: {
        'sans': ['Inter', 'system-ui', 'sans-serif'],
      },
      spacing: {
        '18': '4.5rem',
        '88': '22rem',
      },
      borderRadius: {
        '4xl': '2rem',
      },
      boxShadow: {
        'neon': '0 0 20px rgba(0, 255, 247, 0.5)',
        'neon-purple': '0 0 20px rgba(184, 78, 255, 0.5)',
        'glow': '0 0 30px rgba(0, 255, 247, 0.3)',
      },
    },
  },
  plugins: [],
};