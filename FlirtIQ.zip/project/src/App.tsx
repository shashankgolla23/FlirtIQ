import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import LoadingScreen from './components/LoadingScreen';
import LandingPage from './components/LandingPage';
import TransitionScene from './components/TransitionScene';
import ChatbotInterface from './components/ChatbotInterface';
import StarField from './components/StarField';
import CreatorCredit from './components/CreatorCredit';
import FloatingChatBot from './components/FloatingChatBot';
import { AppProvider } from './context/AppContext';

type AppState = 'loading' | 'landing' | 'transition' | 'planet';

function App() {
  const [appState, setAppState] = useState<AppState>('loading');

  useEffect(() => {
    // Show loading screen for 4 seconds with Interstellar music
    const timer = setTimeout(() => {
      setAppState('landing');
    }, 4000);

    return () => clearTimeout(timer);
  }, []);

  const handleLandingProceed = () => {
    setAppState('transition');
  };

  const handleTransitionComplete = () => {
    setAppState('planet');
  };

  const handleReset = () => {
    setAppState('landing');
  };

  return (
    <AppProvider>
      <div className="min-h-screen bg-space-dark overflow-hidden relative">
        <StarField />
        
        <AnimatePresence mode="wait">
          {appState === 'loading' && (
            <motion.div
              key="loading"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.5 }}
            >
              <LoadingScreen />
            </motion.div>
          )}

          {appState === 'landing' && (
            <motion.div
              key="landing"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.5 }}
              className="relative z-10"
            >
              <LandingPage onProceed={handleLandingProceed} />
            </motion.div>
          )}

          {appState === 'transition' && (
            <motion.div
              key="transition"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.5 }}
              className="relative z-10"
            >
              <TransitionScene onComplete={handleTransitionComplete} />
            </motion.div>
          )}

          {appState === 'planet' && (
            <motion.div
              key="planet"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.5 }}
              className="relative z-10"
            >
              <ChatbotInterface onReset={handleReset} />
            </motion.div>
          )}
        </AnimatePresence>

        {/* Floating ChatBot - Available on all screens except loading */}
        {appState !== 'loading' && <FloatingChatBot />}

        {/* Creator Credit - Always visible */}
        <CreatorCredit />
      </div>
    </AppProvider>
  );
}

export default App;