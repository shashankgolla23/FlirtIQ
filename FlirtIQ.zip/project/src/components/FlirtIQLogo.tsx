import React from 'react';
import { motion } from 'framer-motion';

interface FlirtIQLogoProps {
  size?: number;
  showText?: boolean;
  className?: string;
}

const FlirtIQLogo: React.FC<FlirtIQLogoProps> = ({ 
  size = 80, 
  showText = true, 
  className = "" 
}) => {
  return (
    <div className={`flex items-center gap-3 ${className}`}>
      {/* Logo Icon */}
      <motion.div
        className="relative"
        whileHover={{ scale: 1.05 }}
        transition={{ type: "spring", stiffness: 300 }}
      >
        <div 
          className="relative rounded-full overflow-hidden"
          style={{ width: size, height: size }}
        >
          <img
            src="/download.png"
            alt="FlirtIQ Logo"
            className="w-full h-full object-cover"
          />
          
          {/* Animated border */}
          <div className="absolute inset-0 rounded-full border-2 border-gradient-to-r from-cyan-500 via-purple-500 to-pink-500 animate-spin-slow opacity-70"></div>
          
          {/* Glow effect */}
          <div className="absolute inset-0 rounded-full bg-gradient-to-r from-cyan-500/20 via-purple-500/20 to-pink-500/20 animate-pulse"></div>
        </div>
        
        {/* Outer glow */}
        <div 
          className="absolute inset-0 rounded-full bg-gradient-to-br from-cyan-500 via-purple-500 to-pink-500 opacity-20 blur-lg -z-10"
          style={{ width: size, height: size }}
        />
      </motion.div>
      
      {/* Logo Text */}
      {showText && (
        <motion.div
          initial={{ opacity: 0, x: -10 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.2 }}
          className="flex flex-col"
        >
          <h1 className="text-3xl md:text-4xl font-bold font-orbitron">
            <span className="text-white">Flirt</span>
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-purple-400">IQ</span>
          </h1>
          <p className="text-gray-400 text-sm font-medium tracking-wide">
            AI Conversation Companion
          </p>
        </motion.div>
      )}
    </div>
  );
};

export default FlirtIQLogo;