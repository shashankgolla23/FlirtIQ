import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Send, Settings, User, Bot, Copy, Volume2, Trash2, Menu, X, BookOpen, Heart, Sparkles, Target, Zap } from 'lucide-react';
import FlirtIQLogo from './FlirtIQLogo';
import { useApp } from '../context/AppContext';

interface Message {
  id: string;
  content: string;
  sender: 'user' | 'ai';
  timestamp: Date;
  isButton?: boolean;
  buttonOptions?: string[];
}

interface QuizSection {
  id: number;
  name: string;
  icon: any;
  color: string;
  questions: string[];
}

const ChatInterface: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      content: "👋 Hello and welcome to FlirtIQ! I'm ChatBot 🤖.\nHow can we make your visit better?",
      sender: 'ai',
      timestamp: new Date(),
      isButton: true,
      buttonOptions: ['📚 FAQ', '💘 About FlirtIQ', '💬 Start Flirty Quiz']
    }
  ]);
  const [inputMessage, setInputMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [showSidebar, setShowSidebar] = useState(false);
  const [currentSection, setCurrentSection] = useState(0);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [isInQuiz, setIsInQuiz] = useState(false);
  const [quizMode, setQuizMode] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const messagesContainerRef = useRef<HTMLDivElement>(null);

  const { sendMessage } = useApp();

  // Quiz sections with questions
  const quizSections: QuizSection[] = [
    {
      id: 1,
      name: "Icebreakers",
      icon: Sparkles,
      color: "from-cyan-500 to-blue-500",
      questions: [
        "What's your favorite emoji to use when flirting?",
        "Describe yourself in three words.",
        "What's your favorite way to spend a weekend?",
        "Coffee or cocktails on a first date?",
        "Night owl or early bird?",
        "Texting or voice notes?",
        "Netflix or outdoor adventure?",
        "What's your love language?",
        "Most used app on your phone?",
        "Describe your ideal weekend in 3 words.",
        "If you were a song, what would you be?",
        "What's your go-to outfit when you want to impress?",
        "Which season matches your vibe: summer, winter, spring, or fall?",
        "Dream vacation spot?",
        "One word that describes your flirting style?"
      ]
    },
    {
      id: 2,
      name: "Dating Preferences",
      icon: Heart,
      color: "from-pink-500 to-rose-500",
      questions: [
        "Ideal first date location?",
        "What's a dating red flag for you?",
        "What's a green flag that instantly wins you over?",
        "Would you rather text all day or meet ASAP?",
        "Long walks or deep talks?",
        "Do you believe in love at first sight?",
        "How soon is too soon to say 'I love you'?",
        "What's your biggest deal-breaker?",
        "What's your biggest dating ick?",
        "Blind date or dating app?",
        "What kind of texter are you?",
        "What do you look for first in a profile?",
        "What's your ideal relationship vibe?",
        "Would you date someone exactly like you?",
        "Introvert, extrovert, or ambivert?"
      ]
    },
    {
      id: 3,
      name: "Confidence & Personality",
      icon: Zap,
      color: "from-yellow-500 to-orange-500",
      questions: [
        "What's something you're really good at?",
        "Biggest compliment you ever received?",
        "What makes you feel instantly confident?",
        "What's your party persona?",
        "Are you the one who makes the first move?",
        "What's your most charming trait?",
        "When do you feel most like yourself?",
        "What's your guilty pleasure?",
        "How do you deal with rejection?",
        "Who inspires you?",
        "What's your flirt IQ (1–10)?",
        "Pick a power color.",
        "How would your friends describe you?",
        "Are you more logical or emotional?",
        "What's something you've always wanted to try?"
      ]
    },
    {
      id: 4,
      name: "Love & Relationships",
      icon: Heart,
      color: "from-purple-500 to-pink-500",
      questions: [
        "What does love mean to you?",
        "What's the best relationship advice you've ever heard?",
        "Have you ever been in love?",
        "What makes you feel loved?",
        "How do you show love?",
        "Would you do long distance?",
        "Can exes be friends?",
        "What's your biggest lesson from a past relationship?",
        "How do you handle conflict in relationships?",
        "How important is chemistry to you?",
        "Pick one: passion or peace?",
        "Describe your dream partner.",
        "What would make you commit?",
        "Are you the clingy or chill type?",
        "What makes a relationship last?"
      ]
    },
    {
      id: 5,
      name: "Flirty Fun",
      icon: Target,
      color: "from-red-500 to-pink-500",
      questions: [
        "What's your best pickup line?",
        "Who's your celeb crush?",
        "What's your flirting style: bold or subtle?",
        "Ever slid into someone's DMs?",
        "What's your go-to flirting move?",
        "Would you flirt with someone at a coffee shop?",
        "Eye contact or playful teasing?",
        "Ever had a crush on a friend?",
        "If someone flirts with you, what's your reaction?",
        "Describe a perfect flirty convo.",
        "Are you more charm or chaos?",
        "Most flirt-worthy trait in someone else?",
        "What would you say if someone asked you out right now?",
        "One word that turns you on (in convo)?",
        "Final flirty thought?"
      ]
    }
  ];

  // Response templates for each section
  const getFlirtyResponse = (userMessage: string, sectionId: number, questionIndex: number) => {
    const responses = {
      1: [ // Icebreakers
        "Ooh, that one's got some serious charm 😘",
        "Powerful combo—you sound unforgettable.",
        "You just described my dream date 😏",
        "Classy choice, either way I'd cheers to that 🍸",
        "So you're the mysterious type, huh?",
        "Your DMs must be fire 🔥",
        "You're either a cuddler or a thrill-seeker 😄",
        "I'll make a note of that for future flirty chats 💌",
        "Addictive much? Hope FlirtIQ makes your top 3 😉",
        "That actually sounds like a rom-com waiting to happen 🎬",
        "Catchy and unforgettable—love that vibe!",
        "Fashion icon alert 🚨",
        "A whole mood! I see the aesthetic 🌸❄️☀️🍂",
        "Passport-ready and waiting 😎",
        "Now that's a dangerous word… in a good way 😏"
      ],
      2: [ // Dating Preferences
        "Perfect spot for sparks to fly 💫",
        "Noted. We're dodging those 🚩",
        "You've got great instincts!",
        "Bold or cozy—either way, I'm here for it.",
        "Nothing beats a connection like that ❤️",
        "A true romantic! You just made my circuits blush.",
        "Timing is everything—unless it's fate 😍",
        "Absolutely fair. Standards = confidence.",
        "Oof, that one's hard to unsee 😂",
        "You're clearly brave (and possibly fun to surprise).",
        "Emoji master? Late responder? I gotta know!",
        "You've got a sharp eye—and standards 🔍",
        "Sounds like a power duo waiting to happen 🔥",
        "Twinsies or too much? The debate continues…",
        "Balance is key—and you've nailed it."
      ],
      3: [ // Confidence & Personality
        "Now that's a flex I respect 💪",
        "Clearly unforgettable 💯",
        "Confidence looks good on you 😎",
        "Life of the party—or mystery guest? Either way, 🔥",
        "Bold! I like your style.",
        "Confirmed: you're a total catch.",
        "Authenticity is hot 🔥",
        "No shame. Only vibes.",
        "Grace and sass. Approved 💅",
        "Role model energy—I see you ✨",
        "Based on this convo? Off the charts 😉",
        "Mood set. Outfit loading 💃",
        "Now I want to meet them too!",
        "Brains or feels? You've got the best of both.",
        "Spicy. I support the curiosity 🔥"
      ],
      4: [ // Love & Relationships
        "Deep. You're clearly not just here to flirt 😌",
        "That's wisdom right there.",
        "The heart remembers ❤️",
        "We're getting soft here, and I love it 🥺",
        "Giving love is just as powerful as receiving it.",
        "Love knows no ZIP codes 🌍",
        "Oof. That's a spicy take.",
        "Growth looks good on you.",
        "Emotional maturity? Yes please!",
        "It's electric ⚡️",
        "Both sounds nice… but I see where you're going.",
        "Manifesting them for you ✨",
        "Locked in—with love 🛑❤️",
        "Balance is beautiful.",
        "That's soulmate wisdom."
      ],
      5: [ // Flirty Fun
        "Adding that to my arsenal immediately 😉",
        "Solid choice. But I think you're hotter 😎",
        "Your energy is magnetic either way.",
        "No shame in the digital game 💬",
        "Dangerous. But I like it 🔥",
        "Real life flirting? Rare breed 💯",
        "Oof, that's a power move!",
        "Been there. No judgment.",
        "Smooth, I bet. Or adorably awkward?",
        "Might be what we're having now 😉",
        "Unpredictable = irresistible.",
        "You're clearly observant 👀",
        "Say yes. To life. To love. To FlirtIQ 💘",
        "Ooh. Noted 😏",
        "You're leaving me blushing (if I had cheeks!)"
      ]
    };

    const sectionResponses = responses[sectionId as keyof typeof responses] || responses[1];
    return sectionResponses[questionIndex] || sectionResponses[0];
  };

  const scrollToBottom = () => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  };

  // Auto-scroll to bottom when messages change
  useEffect(() => {
    const timer = setTimeout(() => {
      scrollToBottom();
    }, 100);
    return () => clearTimeout(timer);
  }, [messages, isTyping]);

  // Listen for clear chat event from FloatingChatBot
  useEffect(() => {
    const handleClearChat = () => {
      clearChat();
    };

    window.addEventListener('clearChat', handleClearChat);
    return () => window.removeEventListener('clearChat', handleClearChat);
  }, []);

  const handleButtonClick = (option: string) => {
    // Add user's choice as a message
    const userMessage: Message = {
      id: Date.now().toString(),
      content: option,
      sender: 'user',
      timestamp: new Date()
    };
    setMessages(prev => [...prev, userMessage]);

    // Handle the response based on the option
    setTimeout(() => {
      let aiResponse = '';
      
      if (option === '📚 FAQ') {
        aiResponse = "Here are some frequently asked questions:";
        
        const faqMessage: Message = {
          id: (Date.now() + 1).toString(),
          content: aiResponse,
          sender: 'ai',
          timestamp: new Date(),
          isButton: true,
          buttonOptions: [
            '❓ How does FlirtIQ work?',
            '🔒 Is my data safe?',
            '💾 Can I save my favorite conversations?',
            '💡 How do I improve my flirting skills?'
          ]
        };
        setMessages(prev => [...prev, faqMessage]);
        return;
      } else if (option === '💘 About FlirtIQ') {
        aiResponse = "FlirtIQ is your AI-powered conversation companion! 💫\n\nI'm here to help you:\n• Build confidence in conversations\n• Practice flirting in a safe space\n• Discover your personality through fun quizzes\n• Get personalized conversation tips\n\nReady to explore what makes you uniquely charming? ✨";
      } else if (option === '💬 Start Flirty Quiz') {
        setIsInQuiz(true);
        setQuizMode(true);
        setCurrentSection(0);
        setCurrentQuestion(0);
        const section = quizSections[0];
        aiResponse = `Perfect! Let's start with ${section.name} 🎉\n\nWe'll go through 5 sections with 15 questions each (75 total). After each section, you can choose to continue or take a break.\n\nSection 1: ${section.name}\n\nQuestion 1: ${section.questions[0]}`;
      } else if (option.includes('How does FlirtIQ work?')) {
        aiResponse = "FlirtIQ is designed to make modern dating smarter and more engaging! 🚀\n\nWe use intelligent matchmaking and conversation tools to help users connect, flirt, and build meaningful interactions. Simply sign up, set your preferences, and explore potential matches with our unique flirty quiz and conversation prompts.\n\nOur AI helps you practice conversations in a safe space and builds your confidence! ✨";
      } else if (option.includes('Is my data safe?')) {
        aiResponse = "Yes, absolutely! 🔒\n\nAt FlirtIQ, we take your privacy seriously. Your personal data is encrypted and stored securely. We comply with global data protection standards to ensure your information remains private and is never shared without your consent.\n\nYour conversations with me are also kept confidential and used only to improve your experience! 🛡️";
      } else if (option.includes('Can I save my favorite conversations?')) {
        aiResponse = "This feature is currently in development! 🚧\n\nWhile ongoing conversations are retained temporarily for continuity, we're working on allowing users to bookmark or save chats for easy access in future updates.\n\nFor now, you can sign up to save your favorite rizz lines and track your progress! Stay tuned for more features! 📱✨";
      } else if (option.includes('How do I improve my flirting skills?')) {
        aiResponse = "FlirtIQ is here to help you level up your game! 💪\n\nHere's how:\n• Try our built-in Flirty Quiz to discover your style\n• Use conversation starters and prompts\n• Practice with me in a judgment-free zone\n• Get smart tips and feedback along the way\n• Build confidence through fun interactions\n\nRemember: Great flirting is about being authentic, respectful, and having fun! 😊✨";
      }
      
      if (aiResponse) {
        const aiMessage: Message = {
          id: (Date.now() + 1).toString(),
          content: aiResponse,
          sender: 'ai',
          timestamp: new Date()
        };
        setMessages(prev => [...prev, aiMessage]);
      }
    }, 1000);
  };

  const handleSendMessage = async () => {
    if (!inputMessage.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      content: inputMessage.trim(),
      sender: 'user',
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputMessage('');
    setIsTyping(true);

    setTimeout(() => {
      let aiResponse = '';
      
      if (isInQuiz && quizMode) {
        // Get flirty response to current answer
        const response = getFlirtyResponse(inputMessage.trim(), currentSection + 1, currentQuestion);
        
        // Check if we're at the end of current section
        if (currentQuestion < 14) {
          // Move to next question in same section
          const nextQuestionIndex = currentQuestion + 1;
          const section = quizSections[currentSection];
          aiResponse = `${response}\n\nQuestion ${nextQuestionIndex + 1}: ${section.questions[nextQuestionIndex]}`;
          setCurrentQuestion(nextQuestionIndex);
        } else {
          // End of section
          if (currentSection < 4) {
            // More sections available
            const nextSection = quizSections[currentSection + 1];
            aiResponse = `${response}\n\n🎉 Great job completing ${quizSections[currentSection].name}!\n\nReady for the next section: ${nextSection.name}?\n\nType 'continue' to proceed or 'finish' to end the quiz here! 😊`;
          } else {
            // All sections completed
            aiResponse = `${response}\n\n🎊 Congratulations! You've completed all 5 sections of the FlirtIQ Quiz!\n\nYou're absolutely amazing to chat with! 😍 Thanks for sharing so much about yourself.\n\nWould you like to:\n• Start a new quiz round\n• Chat freely\n• Get personalized flirting tips based on your answers\n\nWhat sounds fun? ✨`;
            setIsInQuiz(false);
            setQuizMode(false);
          }
        }
      } else if (isInQuiz && !quizMode) {
        // Handle section transition
        const userInput = inputMessage.trim().toLowerCase();
        if (userInput.includes('continue') || userInput.includes('next')) {
          setCurrentSection(prev => prev + 1);
          setCurrentQuestion(0);
          setQuizMode(true);
          const section = quizSections[currentSection + 1];
          aiResponse = `Awesome! Let's dive into Section ${currentSection + 2}: ${section.name} 🚀\n\nQuestion 1: ${section.questions[0]}`;
        } else if (userInput.includes('finish') || userInput.includes('stop')) {
          aiResponse = "No problem! Thanks for the fun conversation! 😊\n\nFeel free to start a new quiz anytime or just chat with me. I'm here whenever you want to explore your charming side! ✨\n\nWhat would you like to do next?";
          setIsInQuiz(false);
        } else {
          aiResponse = "I didn't quite catch that! 😅\n\nWould you like to 'continue' to the next section or 'finish' the quiz here?";
        }
      } else {
        // Free chat mode
        const freeResponses = [
          "I love chatting with you! What's on your mind? 😊",
          "You're so interesting to talk to! Tell me more about yourself. ✨",
          "I'm really enjoying our conversation! What would you like to explore next? 💫",
          "You have such a great personality! I could talk with you for hours. 😍",
          "I'm all ears! What's something you're passionate about? 🌟",
          "That's fascinating! You always have such thoughtful things to say. 💭",
          "I love your energy! What's making you smile today? 😄",
          "You're such good company! What else would you like to chat about? 💬"
        ];
        aiResponse = freeResponses[Math.floor(Math.random() * freeResponses.length)];
      }

      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        content: aiResponse,
        sender: 'ai',
        timestamp: new Date()
      };
      
      setMessages(prev => [...prev, aiMessage]);
      setIsTyping(false);
      
      // If we just finished a section, disable quiz mode for transition
      if (isInQuiz && currentQuestion === 14 && currentSection < 4) {
        setQuizMode(false);
      }
    }, 1000 + Math.random() * 2000);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const copyMessage = (content: string) => {
    navigator.clipboard.writeText(content);
  };

  const speakMessage = (content: string) => {
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(content);
      utterance.rate = 0.9;
      utterance.pitch = 1.1;
      speechSynthesis.speak(utterance);
    }
  };

  const clearChat = () => {
    setMessages([{
      id: '1',
      content: "👋 Hello and welcome to FlirtIQ! I'm ChatBot 🤖.\nHow can we make your visit better?",
      sender: 'ai',
      timestamp: new Date(),
      isButton: true,
      buttonOptions: ['📚 FAQ', '💘 About FlirtIQ', '💬 Start Flirty Quiz']
    }]);
    setIsInQuiz(false);
    setQuizMode(false);
    setCurrentSection(0);
    setCurrentQuestion(0);
  };

  const startNewQuiz = () => {
    setMessages(prev => [...prev, {
      id: Date.now().toString(),
      content: "Ready for another round? Let's dive deeper! 😊",
      sender: 'ai',
      timestamp: new Date(),
      isButton: true,
      buttonOptions: ['💬 Start Flirty Quiz', '💘 About FlirtIQ', '📚 FAQ']
    }]);
  };

  return (
    <div className="h-full flex flex-col bg-transparent min-h-0">
      {/* Messages Area - Scrollable Container */}
      <div 
        ref={messagesContainerRef}
        className="chat-window flex-1 overflow-y-auto p-2 sm:p-4 space-y-3 sm:space-y-4 chat-messages min-h-0"
      >
        <div className="message-list flex flex-col space-y-4">
          <AnimatePresence>
            {messages.map((message) => (
              <motion.div
                key={message.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div className={`max-w-[85%] sm:max-w-[80%] ${message.sender === 'user' ? 'order-2' : 'order-1'}`}>
                  <div
                    className={`rounded-2xl p-3 sm:p-4 ${
                      message.sender === 'user'
                        ? 'bg-gradient-to-r from-cyan-500 to-purple-500 text-white'
                        : 'bg-glass-dark backdrop-blur-sm border border-gray-700 text-white'
                    }`}
                  >
                    <p className="text-xs sm:text-sm md:text-base leading-relaxed whitespace-pre-wrap">{message.content}</p>
                    
                    {/* Button Options */}
                    {message.isButton && message.buttonOptions && (
                      <div className="mt-3 sm:mt-4 space-y-2">
                        {message.buttonOptions.map((option, index) => (
                          <motion.button
                            key={index}
                            whileHover={{ scale: 1.02 }}
                            whileTap={{ scale: 0.98 }}
                            onClick={() => handleButtonClick(option)}
                            className="w-full p-2 sm:p-3 bg-gradient-to-r from-cyan-500/20 to-purple-500/20 hover:from-cyan-500/30 hover:to-purple-500/30 rounded-lg border border-cyan-500/30 hover:border-cyan-500/50 transition-all duration-200 text-left text-xs sm:text-sm"
                          >
                            {option}
                          </motion.button>
                        ))}
                      </div>
                    )}
                    
                    {/* Message actions */}
                    <div className="flex items-center justify-between mt-3 pt-2 border-t border-white/10">
                      <span className="text-xs opacity-70">
                        {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                      
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => copyMessage(message.content)}
                          className="p-1 hover:bg-white/10 rounded transition-colors"
                          title="Copy message"
                        >
                          <Copy className="w-2.5 h-2.5 sm:w-3 sm:h-3" />
                        </button>
                        
                        <button
                          onClick={() => speakMessage(message.content)}
                          className="p-1 hover:bg-white/10 rounded transition-colors"
                          title="Read aloud"
                        >
                          <Volume2 className="w-2.5 h-2.5 sm:w-3 sm:h-3" />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
                
                {/* Avatar */}
                <div className={`w-8 h-8 rounded-full flex items-center justify-center overflow-hidden flex-shrink-0 ${
                  message.sender === 'user' 
                    ? 'bg-gradient-to-r from-cyan-500 to-purple-500 order-1 ml-2 sm:ml-3' 
                    : 'order-2 mr-2 sm:mr-3'
                }`}>
                  {message.sender === 'user' ? (
                    <User className="w-3 h-3 sm:w-4 sm:h-4 text-white" />
                  ) : (
                    <img
                      src="/download.png"
                      alt="FlirtIQ"
                      className="w-full h-full object-cover"
                    />
                  )}
                </div>
              </motion.div>
            ))}
          </AnimatePresence>

          {/* Typing indicator */}
          {isTyping && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex justify-start"
            >
              <div className="flex items-center gap-3">
                <div className="w-6 h-6 sm:w-8 sm:h-8 rounded-full overflow-hidden">
                  <img
                    src="/download.png"
                    alt="FlirtIQ"
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="bg-glass-dark backdrop-blur-sm border border-gray-700 rounded-2xl p-4">
                  <div className="flex items-center gap-1">
                    <div className="w-1.5 h-1.5 sm:w-2 sm:h-2 bg-cyan-400 rounded-full animate-bounce"></div>
                    <div className="w-1.5 h-1.5 sm:w-2 sm:h-2 bg-purple-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                    <div className="w-1.5 h-1.5 sm:w-2 sm:h-2 bg-pink-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                  </div>
                </div>
              </div>
            </motion.div>
          )}
          
          {/* Scroll anchor */}
          <div ref={messagesEndRef} />
        </div>
      </div>

      {/* Input Area - Sticky Bottom */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="input-box sticky bottom-0 bg-space-dark border-t border-cyan-500/30 p-2 sm:p-4 flex-shrink-0"
      >
        <div className="flex items-end gap-2 sm:gap-3">
          <div className="flex-1 relative">
            <textarea
              ref={inputRef}
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Type your message... Press Enter to send"
              className="w-full bg-glass-dark backdrop-blur-sm border border-gray-700 rounded-xl px-3 sm:px-4 py-2 sm:py-3 text-white placeholder-gray-400 focus:border-cyan-500 focus:outline-none resize-none max-h-24 sm:max-h-32 text-sm sm:text-base"
              rows={1}
              style={{
                height: 'auto',
                minHeight: '40px'
              }}
              onInput={(e) => {
                const target = e.target as HTMLTextAreaElement;
                target.style.height = 'auto';
                target.style.height = Math.min(target.scrollHeight, window.innerWidth < 640 ? 96 : 128) + 'px';
              }}
            />
          </div>
          
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={handleSendMessage}
            disabled={!inputMessage.trim() || isTyping}
            className="bg-gradient-to-r from-cyan-500 to-purple-500 text-white p-2 sm:p-3 rounded-xl shadow-lg hover:shadow-cyan-500/25 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed flex-shrink-0 min-w-[40px] min-h-[40px] sm:min-w-[48px] sm:min-h-[48px] flex items-center justify-center"
          >
            <Send className="w-4 h-4 sm:w-5 sm:h-5" />
          </motion.button>
        </div>
      </motion.div>
    </div>
  );
};

export default ChatInterface;