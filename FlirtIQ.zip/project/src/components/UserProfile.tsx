import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { User, Settings, LogOut, Heart, Zap, Crown, ChevronDown } from 'lucide-react';

interface UserProfileProps {
  user: any;
  onLogout: () => void;
}

const UserProfile: React.FC<UserProfileProps> = ({ user, onLogout }) => {
  const [showDropdown, setShowDropdown] = useState(false);

  return (
    <div className="relative">
      <motion.button
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onClick={() => setShowDropdown(!showDropdown)}
        className="flex items-center gap-3 bg-glass-dark backdrop-blur-sm rounded-full px-4 py-2 border border-purple-500/30 hover:border-purple-500/60 transition-all duration-300"
      >
        <div className="w-8 h-8 rounded-full bg-gradient-to-r from-cyan-500 to-purple-500 flex items-center justify-center overflow-hidden">
          {user.avatar ? (
            <img
              src={user.avatar}
              alt={user.firstName || user.username}
              className="w-full h-full object-cover"
            />
          ) : (
            <User className="w-4 h-4 text-white" />
          )}
        </div>
        <div className="hidden md:block text-left">
          <p className="text-white text-sm font-medium">
            {user.firstName || user.username || 'User'}
          </p>
          <p className="text-gray-400 text-xs">
            {user.stats?.rizzGenerated || 0} rizz generated
          </p>
        </div>
        <ChevronDown className={`w-4 h-4 text-gray-400 transition-transform ${showDropdown ? 'rotate-180' : ''}`} />
      </motion.button>

      <AnimatePresence>
        {showDropdown && (
          <motion.div
            initial={{ opacity: 0, y: 10, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 10, scale: 0.95 }}
            transition={{ duration: 0.2 }}
            className="absolute top-full right-0 mt-2 w-80 bg-glass-dark backdrop-blur-sm rounded-xl border border-purple-500/30 shadow-xl z-50"
          >
            {/* User Info */}
            <div className="p-4 border-b border-gray-700">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-12 h-12 rounded-full bg-gradient-to-r from-cyan-500 to-purple-500 flex items-center justify-center overflow-hidden">
                  {user.avatar ? (
                    <img
                      src={user.avatar}
                      alt={user.firstName || user.username}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <User className="w-6 h-6 text-white" />
                  )}
                </div>
                <div>
                  <h3 className="text-white font-semibold">
                    {user.firstName && user.lastName 
                      ? `${user.firstName} ${user.lastName}`
                      : user.username || 'User'
                    }
                  </h3>
                  <p className="text-gray-400 text-sm">{user.email}</p>
                </div>
              </div>

              {/* User Stats */}
              <div className="grid grid-cols-3 gap-3">
                <div className="text-center">
                  <div className="flex items-center justify-center gap-1 mb-1">
                    <Zap className="w-4 h-4 text-cyan-400" />
                    <span className="text-white font-bold">{user.stats?.rizzGenerated || 0}</span>
                  </div>
                  <p className="text-gray-400 text-xs">Rizz Generated</p>
                </div>
                <div className="text-center">
                  <div className="flex items-center justify-center gap-1 mb-1">
                    <Heart className="w-4 h-4 text-red-400" />
                    <span className="text-white font-bold">{user.stats?.favoriteLines || 0}</span>
                  </div>
                  <p className="text-gray-400 text-xs">Favorites</p>
                </div>
                <div className="text-center">
                  <div className="flex items-center justify-center gap-1 mb-1">
                    <Crown className="w-4 h-4 text-yellow-400" />
                    <span className="text-white font-bold">{user.stats?.streak || 0}</span>
                  </div>
                  <p className="text-gray-400 text-xs">Day Streak</p>
                </div>
              </div>
            </div>

            {/* Menu Items */}
            <div className="p-2">
              <button className="w-full flex items-center gap-3 p-3 text-gray-300 hover:text-white hover:bg-white/5 rounded-lg transition-all duration-200">
                <Settings className="w-5 h-5" />
                <span>Account Settings</span>
              </button>
              
              <button className="w-full flex items-center gap-3 p-3 text-gray-300 hover:text-white hover:bg-white/5 rounded-lg transition-all duration-200">
                <Heart className="w-5 h-5" />
                <span>Favorite Rizz</span>
              </button>
              
              <button 
                onClick={onLogout}
                className="w-full flex items-center gap-3 p-3 text-red-400 hover:text-red-300 hover:bg-red-500/10 rounded-lg transition-all duration-200"
              >
                <LogOut className="w-5 h-5" />
                <span>Sign Out</span>
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Overlay to close dropdown */}
      {showDropdown && (
        <div
          className="fixed inset-0 z-40"
          onClick={() => setShowDropdown(false)}
        />
      )}
    </div>
  );
};

export default UserProfile;