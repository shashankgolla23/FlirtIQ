import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Rocket, Coffee } from 'lucide-react';

interface LandingPageProps {
  onProceed: () => void;
}

const LandingPage: React.FC<LandingPageProps> = ({ onProceed }) => {
  const [displayText, setDisplayText] = useState('');
  const [showButtons, setShowButtons] = useState(false);
  const [showTooltip, setShowTooltip] = useState(false);

  const fullText = "Welcome to FLIRTIQ\nYour AI-Powered Conversation Companion\nReady to explore the cosmos of charm?";

  useEffect(() => {
    let index = 0;
    const timer = setInterval(() => {
      if (index < fullText.length) {
        setDisplayText(fullText.slice(0, index + 1));
        index++;
      } else {
        clearInterval(timer);
        setTimeout(() => setShowButtons(true), 500);
      }
    }, 50);

    return () => clearInterval(timer);
  }, []);

  const handleNoClick = () => {
    setShowTooltip(true);
    setTimeout(() => {
      setShowTooltip(false);
      onProceed();
    }, 2000);
  };

  return (
    <div className="min-h-screen flex items-center justify-center relative">
      {/* Floating particles */}
      <div className="absolute inset-0 pointer-events-none">
        {[...Array(50)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-1 h-1 bg-cyan-400 rounded-full"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
            animate={{
              opacity: [0, 1, 0],
              scale: [0, 1, 0],
              y: [0, -100],
            }}
            transition={{
              duration: 3 + Math.random() * 2,
              repeat: Infinity,
              delay: Math.random() * 2,
            }}
          />
        ))}
      </div>

      <div className="text-center max-w-4xl mx-auto px-4 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1 }}
          className="mb-16"
        >
          <div className="text-4xl md:text-6xl font-bold text-white mb-8 leading-tight font-orbitron">
            {displayText.split('\n').map((line, index) => (
              <div key={index} className="block mb-2">
                {index === 0 && line.includes('FLIRTIQ') ? (
                  <>
                    Welcome to{' '}
                    <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-purple-400">
                      FLIRTIQ
                    </span>
                  </>
                ) : (
                  <span className={index === 1 ? 'text-2xl md:text-3xl text-gray-300 font-normal' : ''}>
                    {line}
                  </span>
                )}
              </div>
            ))}
            <span className="animate-pulse text-cyan-400">|</span>
          </div>
        </motion.div>

        {showButtons && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="space-y-4"
          >
            <p className="text-xl text-gray-300 mb-8">Ready to begin your cosmic journey?</p>
            
            <div className="flex flex-col md:flex-row gap-4 justify-center items-center">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={onProceed}
                className="group relative overflow-hidden bg-gradient-to-r from-cyan-500 to-purple-500 text-white px-8 py-4 rounded-full font-semibold text-lg shadow-lg hover:shadow-cyan-500/25 transition-all duration-300"
              >
                <span className="relative z-10 flex items-center gap-2">
                  <Rocket className="w-5 h-5" />
                  Launch FlirtIQ 🚀
                </span>
                <div className="absolute inset-0 bg-gradient-to-r from-cyan-400 to-purple-400 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              </motion.button>

              <div className="relative">
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={handleNoClick}
                  className="group relative overflow-hidden bg-gray-600 text-gray-300 px-8 py-4 rounded-full font-semibold text-lg shadow-lg hover:shadow-gray-500/25 transition-all duration-300"
                >
                  <span className="relative z-10 flex items-center gap-2">
                    <Coffee className="w-5 h-5" />
                    Maybe Later 🥱
                  </span>
                </motion.button>
                
                {showTooltip && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 10 }}
                    className="absolute -top-16 left-1/2 transform -translate-x-1/2 bg-black/80 text-white px-4 py-2 rounded-lg text-sm whitespace-nowrap"
                  >
                    Too late, we're launching anyway! 😉
                    <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 translate-y-full w-0 h-0 border-l-4 border-r-4 border-t-4 border-transparent border-t-black/80"></div>
                  </motion.div>
                )}
              </div>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
};

export default LandingPage;