import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import FlirtIQLogo from './FlirtIQLogo';

const LoadingScreen: React.FC = () => {
  const [loadingText, setLoadingText] = useState('Initializing FlirtIQ...');
  const [progress, setProgress] = useState(0);

  const loadingStages = [
    'Initializing FlirtIQ...',
    'Connecting to AI consciousness...',
    'Loading cosmic charm algorithms...',
    'Preparing conversation engine...',
    'Welcome to FlirtIQ! 🌟'
  ];

  useEffect(() => {
    // Try to play Interstellar music with better error handling
    const audio = new Audio('/interstellar-theme.mp3');
    audio.volume = 0.3;
    audio.loop = true;
    
    const playMusic = async () => {
      try {
        await audio.play();
      } catch (error) {
        console.log('Audio autoplay prevented or file not found:', error);
      }
    };

    playMusic();

    let currentStage = 0;
    const stageTimer = setInterval(() => {
      if (currentStage < loadingStages.length - 1) {
        currentStage++;
        setLoadingText(loadingStages[currentStage]);
        setProgress((currentStage / (loadingStages.length - 1)) * 100);
      } else {
        clearInterval(stageTimer);
        // Fade out music
        const fadeOut = setInterval(() => {
          if (audio.volume > 0.1) {
            audio.volume -= 0.1;
          } else {
            audio.pause();
            clearInterval(fadeOut);
          }
        }, 100);
      }
    }, 800);

    return () => {
      clearInterval(stageTimer);
      audio.pause();
    };
  }, []);

  return (
    <div className="min-h-screen relative overflow-hidden bg-gradient-to-br from-space-dark via-purple-900/20 to-cyan-900/20">
      {/* Animated background without WebGL */}
      <div className="absolute inset-0">
        {[...Array(100)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-1 h-1 bg-white rounded-full"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
            animate={{
              opacity: [0.2, 1, 0.2],
              scale: [0.5, 1.5, 0.5],
            }}
            transition={{
              duration: 2 + Math.random() * 3,
              repeat: Infinity,
              delay: Math.random() * 2,
            }}
          />
        ))}
      </div>

      <div className="relative z-10 flex flex-col items-center justify-center min-h-screen px-4">
        {/* Loading Animation */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2, duration: 0.8 }}
          className="text-center mb-8"
        >
          {/* FlirtIQ Title */}
          <motion.h1
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1, duration: 0.8 }}
            className="text-4xl md:text-5xl font-bold font-orbitron mb-8"
          >
            <span className="text-white">Flirt</span>
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-purple-400">IQ</span>
          </motion.h1>
          
          <div className="relative mb-8 flex justify-center">
            <FlirtIQLogo size={120} showText={false} />
          </div>
          
          <motion.h2
            key={loadingText}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-2xl md:text-3xl font-bold text-white mb-6 font-orbitron"
          >
            {loadingText}
          </motion.h2>
          
          {/* Progress Bar */}
          <div className="w-80 h-2 bg-gray-800 rounded-full mx-auto overflow-hidden mb-4">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${progress}%` }}
              transition={{ duration: 0.5, ease: "easeOut" }}
              className="h-full bg-gradient-to-r from-cyan-500 to-purple-500 rounded-full"
            />
          </div>
          
          <p className="text-gray-400 text-lg">
            {Math.round(progress)}% Complete
          </p>
          
          {/* Music indicator */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1 }}
            className="mt-6 flex items-center justify-center gap-2 text-cyan-400"
          >
            <div className="w-2 h-2 bg-cyan-400 rounded-full animate-pulse"></div>
            <span className="text-sm">🎵 Cosmic music loading...</span>
            <div className="w-2 h-2 bg-cyan-400 rounded-full animate-pulse"></div>
          </motion.div>
        </motion.div>

        {/* Cosmic particles */}
        <div className="absolute inset-0 pointer-events-none">
          {[...Array(20)].map((_, i) => (
            <motion.div
              key={i}
              className="absolute w-1 h-1 bg-cyan-400 rounded-full"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
              }}
              animate={{
                opacity: [0, 1, 0],
                scale: [0, 1, 0],
              }}
              transition={{
                duration: 2 + Math.random() * 2,
                repeat: Infinity,
                delay: Math.random() * 2,
              }}
            />
          ))}
        </div>
      </div>
    </div>
  );
};

export default LoadingScreen;