import React from 'react';
import { motion } from 'framer-motion';
import { User, Zap, Heart, BookOpen, Sparkles } from 'lucide-react';

interface AvatarSelectorProps {
  selectedAvatar: string;
  onAvatarChange: (avatar: string) => void;
}

const avatars = [
  { id: 'alien', name: 'Alien Baddie', icon: Sparkles, color: 'from-purple-500 to-pink-500', personality: 'Out of this world confidence' },
  { id: 'don', name: 'Desi Don', icon: Zap, color: 'from-orange-500 to-red-500', personality: 'Bollywood charm' },
  { id: 'nerd', name: 'Nerdy Crush', icon: BookOpen, color: 'from-blue-500 to-cyan-500', personality: 'Intellectual appeal' },
  { id: 'romantic', name: 'Romantic Soul', icon: Heart, color: 'from-pink-500 to-rose-500', personality: 'Hopeless romantic' },
  { id: 'cool', name: 'Cool Cat', icon: User, color: 'from-green-500 to-emerald-500', personality: 'Laid-back vibes' },
];

const AvatarSelector: React.FC<AvatarSelectorProps> = ({ selectedAvatar, onAvatarChange }) => {
  return (
    <div className="bg-glass-dark backdrop-blur-sm rounded-xl p-6 border border-purple-500/30">
      <h3 className="text-xl font-semibold text-white mb-4">
        <User className="w-5 h-5 inline mr-2 text-purple-400" />
        Choose Your AI Wingman
      </h3>
      
      <div className="flex flex-wrap gap-3">
        {avatars.map((avatar) => {
          const IconComponent = avatar.icon;
          return (
            <motion.button
              key={avatar.id}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => onAvatarChange(avatar.id)}
              className={`flex items-center gap-3 p-3 rounded-xl border-2 transition-all duration-300 ${
                selectedAvatar === avatar.id
                  ? 'border-purple-500 bg-purple-500/10'
                  : 'border-gray-700 hover:border-gray-600'
              }`}
            >
              <div className={`w-10 h-10 rounded-full bg-gradient-to-r ${avatar.color} flex items-center justify-center`}>
                <IconComponent className="w-5 h-5 text-white" />
              </div>
              <div className="text-left">
                <h4 className="text-white font-medium text-sm">{avatar.name}</h4>
                <p className="text-gray-400 text-xs">{avatar.personality}</p>
              </div>
            </motion.button>
          );
        })}
      </div>
    </div>
  );
};

export default AvatarSelector;