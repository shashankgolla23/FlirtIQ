import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { MessageCircle, X, Minimize2, Maximize2, Settings, Trash2, Moon, Sun } from 'lucide-react';
import ChatInterface from './ChatInterface';

const FloatingChatBot: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [darkMode, setDarkMode] = useState(() => {
    return localStorage.getItem('chatbot-theme') !== 'light';
  });

  const toggleChat = () => {
    setIsOpen(!isOpen);
    setIsMinimized(false);
  };

  const minimizeChat = () => {
    setIsMinimized(true);
    setIsExpanded(false);
  };

  const expandChat = () => {
    setIsExpanded(!isExpanded);
    setIsMinimized(false);
  };

  const closeChat = () => {
    setIsOpen(false);
    setIsMinimized(false);
    setIsExpanded(false);
    setShowSettings(false);
  };

  const clearChat = () => {
    // This will be handled by the ChatInterface component
    const event = new CustomEvent('clearChat');
    window.dispatchEvent(event);
    setShowSettings(false);
  };

  const toggleDarkMode = () => {
    const newMode = !darkMode;
    setDarkMode(newMode);
    localStorage.setItem('chatbot-theme', newMode ? 'dark' : 'light');
    
    // Apply theme to chat container
    const chatContainer = document.querySelector('.chat-container');
    if (chatContainer) {
      chatContainer.classList.toggle('dark', newMode);
      chatContainer.classList.toggle('light', !newMode);
    }
  };

  // Determine chat window size
  const getChatWindowSize = () => {
    if (isMinimized) return 'bottom-4 left-4 w-72 h-16 sm:w-80 sm:h-20';
    if (isExpanded) return 'bottom-4 left-4 right-4 top-4 w-auto h-auto max-w-none';
    return 'bottom-4 left-4 w-80 h-[500px] sm:w-96 sm:h-[600px] md:w-[420px] md:h-[650px] lg:w-[500px] lg:h-[700px] max-w-[calc(100vw-2rem)] max-h-[calc(100vh-2rem)]';
  };

  return (
    <>
      {/* Floating Chat Button */}
      <AnimatePresence>
        {!isOpen && (
          <motion.button
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0, opacity: 0 }}
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            onClick={toggleChat}
            className="fixed bottom-6 left-6 w-16 h-16 bg-gradient-to-r from-cyan-500 to-purple-500 rounded-full shadow-lg hover:shadow-cyan-500/25 transition-all duration-300 z-50 flex items-center justify-center"
          >
            <MessageCircle className="w-8 h-8 text-white" />
            
            {/* Notification dot */}
            <div className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full flex items-center justify-center">
              <span className="text-white text-xs font-bold">!</span>
            </div>
            
            {/* Pulse animation */}
            <div className="absolute inset-0 rounded-full bg-gradient-to-r from-cyan-500 to-purple-500 animate-ping opacity-20"></div>
          </motion.button>
        )}
      </AnimatePresence>

      {/* Chat Window */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.8, y: 100 }}
            animate={{ 
              opacity: 1, 
              scale: 1, 
              y: 0 
            }}
            exit={{ opacity: 0, scale: 0.8, y: 100 }}
            transition={{ type: "spring", stiffness: 300, damping: 30 }}
            className={`fixed z-50 bg-glass-dark backdrop-blur-sm rounded-2xl border border-cyan-500/30 shadow-2xl ${getChatWindowSize()} ${
              darkMode ? 'chat-container dark' : 'chat-container light'
            } overflow-hidden`}
            style={{
              transformOrigin: 'bottom left'
            }}
          >
            {/* Chat Header */}
            <div className="chat-header flex items-center justify-between p-3 sm:p-4 border-b border-gray-700 relative flex-shrink-0">
              <div className="flex items-center gap-3 flex-1">
                <div className="w-6 h-6 sm:w-8 sm:h-8 rounded-full overflow-hidden flex-shrink-0">
                  <img
                    src="/download.png"
                    alt="FlirtIQ"
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="min-w-0 flex-1">
                  <h3 className="text-white font-semibold font-orbitron truncate text-sm sm:text-base">FlirtIQ ChatBot</h3>
                  <p className="text-gray-400 text-xs truncate hidden sm:block">Online • Ready to chat</p>
                </div>
              </div>
              
              {/* Header Buttons Container */}
              <div className="chat-header-buttons flex items-center gap-2 flex-shrink-0 ml-4">
                <button
                  onClick={() => setShowSettings(!showSettings)}
                  className="p-1.5 sm:p-2 text-gray-400 hover:text-white hover:bg-white/10 rounded-lg transition-all duration-200 min-w-[32px] min-h-[32px] sm:min-w-[36px] sm:min-h-[36px] flex items-center justify-center"
                  title="Settings"
                >
                  <Settings className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                </button>
                
                <button
                  onClick={expandChat}
                  className="p-1.5 sm:p-2 text-gray-400 hover:text-white hover:bg-white/10 rounded-lg transition-all duration-200 min-w-[32px] min-h-[32px] sm:min-w-[36px] sm:min-h-[36px] flex items-center justify-center"
                  title={isExpanded ? "Restore" : "Expand"}
                >
                  <Maximize2 className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                </button>
                
                <button
                  onClick={minimizeChat}
                  className="p-1.5 sm:p-2 text-gray-400 hover:text-white hover:bg-white/10 rounded-lg transition-all duration-200 min-w-[32px] min-h-[32px] sm:min-w-[36px] sm:min-h-[36px] flex items-center justify-center"
                  title="Minimize"
                >
                  <Minimize2 className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                </button>
                
                <button
                  onClick={closeChat}
                  className="p-1.5 sm:p-2 text-gray-400 hover:text-red-400 hover:bg-red-500/10 rounded-lg transition-all duration-200 min-w-[32px] min-h-[32px] sm:min-w-[36px] sm:min-h-[36px] flex items-center justify-center"
                  title="Close"
                >
                  <X className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                </button>
              </div>

              {/* Settings Dropdown */}
              <AnimatePresence>
                {showSettings && (
                  <motion.div
                    initial={{ opacity: 0, y: -10, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: -10, scale: 0.95 }}
                    className="absolute top-full right-2 sm:right-4 mt-2 w-56 sm:w-64 bg-glass-dark backdrop-blur-sm rounded-xl border border-cyan-500/30 shadow-xl z-50"
                  >
                    <div className="p-4">
                      <h4 className="text-white font-semibold mb-4">Chat Settings</h4>
                      
                      <div className="space-y-3">
                        {/* Clear Chat Option */}
                        <button
                          onClick={clearChat}
                          className="w-full flex items-center gap-3 p-3 text-red-400 hover:text-red-300 hover:bg-red-500/10 rounded-lg transition-all duration-200"
                        >
                          <Trash2 className="w-4 h-4" />
                          <span>Clear Chat</span>
                        </button>
                        
                        {/* Dark/Light Mode Toggle */}
                        <div className="flex items-center justify-between p-3 hover:bg-white/5 rounded-lg transition-all duration-200">
                          <div className="flex items-center gap-3">
                            {darkMode ? (
                              <Moon className="w-4 h-4 text-blue-400" />
                            ) : (
                              <Sun className="w-4 h-4 text-yellow-400" />
                            )}
                            <span className="text-gray-300">
                              {darkMode ? 'Dark Mode' : 'Light Mode'}
                            </span>
                          </div>
                          
                          <button
                            onClick={toggleDarkMode}
                            className={`w-12 h-6 rounded-full relative transition-colors duration-300 ${
                              darkMode ? 'bg-blue-500' : 'bg-gray-600'
                            }`}
                          >
                            <div
                              className={`w-5 h-5 bg-white rounded-full absolute top-0.5 transition-transform duration-300 ${
                                darkMode ? 'translate-x-6' : 'translate-x-0.5'
                              }`}
                            />
                          </button>
                        </div>
                        
                        {/* Theme Info */}
                        <div className="text-xs text-gray-400 p-2 bg-black/20 rounded-lg">
                          💡 Theme preference is saved locally
                        </div>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* Chat Content */}
            {!isMinimized && (
              <div className="flex-1 overflow-hidden min-h-0">
                <ChatInterface />
              </div>
            )}
            
            {/* Minimized Preview */}
            {isMinimized && (
              <div className="p-2 sm:p-4 text-center">
                <div className="text-gray-400 text-xs sm:text-sm mb-1 sm:mb-2">Chat minimized</div>
                <button
                  onClick={() => setIsMinimized(false)}
                  className="text-cyan-400 hover:text-cyan-300 text-xs sm:text-sm underline"
                >
                  Click to expand
                </button>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Settings Overlay */}
      {showSettings && (
        <div
          className="fixed inset-0 z-40"
          onClick={() => setShowSettings(false)}
        />
      )}
    </>
  );
};

export default FloatingChatBot;