import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { useApp } from '../context/AppContext';
import FlirtIQLogo from './FlirtIQLogo';

interface TransitionSceneProps {
  onComplete: () => void;
}

const TransitionScene: React.FC<TransitionSceneProps> = ({ onComplete }) => {
  const [stage, setStage] = useState(0);
  const [loadingText, setLoadingText] = useState('Preparing for launch...');
  const { playInterstellarMusic } = useApp();

  const stages = [
    'Preparing for launch...',
    'Leaving Earth orbit...',
    'Entering hyperspace...',
    'Navigating through wormhole...',
    'Approaching FlirtIQ Planet...',
    'Landing sequence initiated...',
    'Welcome to FlirtIQ Planet! 🪐'
  ];

  useEffect(() => {
    // Play interstellar music when transition starts
    if (playInterstellarMusic) {
      playInterstellarMusic();
    }
    
    const timer = setInterval(() => {
      setStage(prev => {
        if (prev < stages.length - 1) {
          setLoadingText(stages[prev + 1]);
          return prev + 1;
        } else {
          clearInterval(timer);
          setTimeout(onComplete, 1000);
          return prev;
        }
      });
    }, 1500);

    return () => clearInterval(timer);
  }, [onComplete, playInterstellarMusic]);

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Animated background without WebGL */}
      <div className="absolute inset-0">
        {[...Array(200)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-1 h-1 bg-white rounded-full"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
            animate={{
              opacity: [0.1, 1, 0.1],
              scale: [0.5, 2, 0.5],
              y: [0, -window.innerHeight],
            }}
            transition={{
              duration: 3 + Math.random() * 2,
              repeat: Infinity,
              delay: Math.random() * 2,
            }}
          />
        ))}
      </div>

      {/* Wormhole Effect */}
      <div className="absolute inset-0 flex items-center justify-center">
        <motion.div
          className="w-96 h-96 rounded-full border-4 border-cyan-500/30"
          animate={{
            scale: [1, 2, 1],
            rotate: 360,
            borderColor: ['rgba(6, 182, 212, 0.3)', 'rgba(168, 85, 247, 0.3)', 'rgba(236, 72, 153, 0.3)']
          }}
          transition={{
            duration: 2,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />
        <motion.div
          className="absolute w-64 h-64 rounded-full border-2 border-purple-500/50"
          animate={{
            scale: [1, 1.5, 1],
            rotate: -360,
          }}
          transition={{
            duration: 3,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />
        <motion.div
          className="absolute w-32 h-32 rounded-full border border-pink-500/70"
          animate={{
            scale: [1, 3, 1],
            rotate: 360,
          }}
          transition={{
            duration: 1.5,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />
      </div>

      {/* Gravitational waves */}
      {[...Array(5)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute inset-0 rounded-full border border-cyan-400/20"
          style={{
            width: `${200 + i * 100}px`,
            height: `${200 + i * 100}px`,
            left: '50%',
            top: '50%',
            transform: 'translate(-50%, -50%)'
          }}
          animate={{
            scale: [1, 2, 1],
            opacity: [0.5, 0, 0.5]
          }}
          transition={{
            duration: 2,
            repeat: Infinity,
            delay: i * 0.4,
            ease: "easeOut"
          }}
        />
      ))}

      <div className="relative z-10 flex flex-col items-center justify-center min-h-screen">
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-8"
        >
          <div className="relative">
            <div className="w-32 h-32 mx-auto mb-8 relative flex justify-center">
              <FlirtIQLogo size={120} showText={false} />
            </div>
          </div>
          
          <motion.h2
            key={loadingText}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-2xl md:text-3xl font-bold text-white mb-4 font-orbitron"
          >
            {loadingText}
          </motion.h2>
          
          <div className="w-64 h-2 bg-gray-800 rounded-full mx-auto overflow-hidden">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${((stage + 1) / stages.length) * 100}%` }}
              transition={{ duration: 0.5 }}
              className="h-full bg-gradient-to-r from-cyan-500 to-purple-500 rounded-full"
            />
          </div>
          
          <p className="text-gray-400 mt-4">
            {Math.round(((stage + 1) / stages.length) * 100)}% Complete
          </p>
          
          {/* Music indicator */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1 }}
            className="mt-6 flex items-center justify-center gap-2 text-cyan-400"
          >
            <div className="w-2 h-2 bg-cyan-400 rounded-full animate-pulse"></div>
            <span className="text-sm">🎵 Interstellar music playing...</span>
            <div className="w-2 h-2 bg-cyan-400 rounded-full animate-pulse"></div>
          </motion.div>
        </motion.div>
      </div>
    </div>
  );
};

export default TransitionScene;