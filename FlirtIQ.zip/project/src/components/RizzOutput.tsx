import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Copy, RefreshCw, Share2, Volume2, Heart, CheckCircle, User, Zap, BookOpen, Sparkles, UserPlus } from 'lucide-react';

interface RizzOutputProps {
  rizz: string;
  isGenerating: boolean;
  onCopy: () => void;
  onRegenerate: () => void;
  onShare: () => void;
  onFavorite?: () => void;
  avatar: string;
  showAuthPrompt?: boolean;
}

const avatarConfig = {
  alien: { name: 'Alien Baddie', icon: Sparkles, emoji: '👽', color: 'from-purple-500 to-pink-500' },
  don: { name: 'Desi Don', icon: Zap, emoji: '🎬', color: 'from-orange-500 to-red-500' },
  nerd: { name: 'Nerdy Crush', icon: BookOpen, emoji: '🧠', color: 'from-blue-500 to-cyan-500' },
  romantic: { name: 'Romantic Soul', icon: Heart, emoji: '💞', color: 'from-pink-500 to-rose-500' },
  cool: { name: 'Cool Cat', icon: User, emoji: '😎', color: 'from-green-500 to-emerald-500' },
};

const RizzOutput: React.FC<RizzOutputProps> = ({
  rizz,
  isGenerating,
  onCopy,
  onRegenerate,
  onShare,
  onFavorite,
  avatar,
  showAuthPrompt = false
}) => {
  const [copied, setCopied] = useState(false);
  const [liked, setLiked] = useState(false);
  const [isTyping, setIsTyping] = useState(false);

  const currentAvatar = avatarConfig[avatar as keyof typeof avatarConfig] || avatarConfig.alien;

  const handleCopy = () => {
    onCopy();
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleLike = () => {
    if (onFavorite) {
      onFavorite();
      setLiked(true);
      setTimeout(() => setLiked(false), 1000);
    }
  };

  const handleSpeak = () => {
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(rizz);
      utterance.rate = 0.9;
      utterance.pitch = 1.1;
      speechSynthesis.speak(utterance);
    }
  };

  // Simulate typing animation when new rizz is generated
  React.useEffect(() => {
    if (rizz && !isGenerating) {
      setIsTyping(true);
      const timer = setTimeout(() => setIsTyping(false), 1500);
      return () => clearTimeout(timer);
    }
  }, [rizz, isGenerating]);

  return (
    <div className="bg-glass-dark backdrop-blur-sm rounded-xl p-6 border border-purple-500/30 h-full">
      <h3 className="text-xl font-semibold text-white mb-4">
        <Heart className="w-5 h-5 inline mr-2 text-purple-400" />
        Your Generated Rizz
      </h3>
      
      <div className="space-y-4">
        {/* Avatar Display */}
        <div className="flex items-center gap-3 mb-4">
          <div className={`w-12 h-12 rounded-full bg-gradient-to-r ${currentAvatar.color} flex items-center justify-center`}>
            <span className="text-2xl">{currentAvatar.emoji}</span>
          </div>
          <div>
            <h4 className="text-white font-medium">{currentAvatar.name}</h4>
            <p className="text-gray-400 text-sm">Your AI Wingman ✨</p>
          </div>
        </div>

        {/* Rizz Display */}
        <div className="min-h-[200px] bg-black/30 rounded-lg p-4 border border-gray-700 relative">
          <AnimatePresence mode="wait">
            {isGenerating ? (
              <motion.div
                key="generating"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="flex items-center justify-center h-full"
              >
                <div className="text-center">
                  <div className="w-8 h-8 border-2 border-cyan-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
                  <p className="text-gray-400">Crafting the perfect rizz...</p>
                  <div className="flex items-center justify-center gap-1 mt-2">
                    <div className="w-2 h-2 bg-cyan-400 rounded-full animate-bounce"></div>
                    <div className="w-2 h-2 bg-purple-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                    <div className="w-2 h-2 bg-pink-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                  </div>
                </div>
              </motion.div>
            ) : rizz ? (
              <motion.div
                key="rizz"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="space-y-4"
              >
                <div className="bg-gradient-to-r from-cyan-500/10 to-purple-500/10 rounded-lg p-4 border-l-4 border-cyan-500">
                  {isTyping ? (
                    <div className="flex items-center gap-1">
                      <div className="w-2 h-2 bg-cyan-400 rounded-full animate-bounce"></div>
                      <div className="w-2 h-2 bg-purple-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                      <div className="w-2 h-2 bg-pink-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                    </div>
                  ) : (
                    <motion.p 
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ duration: 0.5 }}
                      className="text-white text-lg leading-relaxed"
                    >
                      {rizz}
                    </motion.p>
                  )}
                </div>
                
                {!isTyping && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.3 }}
                  >
                    {/* Action Buttons */}
                    <div className="flex flex-wrap gap-2 mb-4">
                      <motion.button
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        onClick={handleCopy}
                        className="flex items-center gap-2 px-4 py-2 bg-cyan-500/20 text-cyan-400 rounded-lg hover:bg-cyan-500/30 transition-colors"
                      >
                        {copied ? <CheckCircle className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                        {copied ? 'Copied!' : 'Copy'}
                      </motion.button>
                      
                      <motion.button
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        onClick={onRegenerate}
                        className="flex items-center gap-2 px-4 py-2 bg-purple-500/20 text-purple-400 rounded-lg hover:bg-purple-500/30 transition-colors"
                      >
                        <RefreshCw className="w-4 h-4" />
                        Regenerate
                      </motion.button>
                      
                      <motion.button
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        onClick={handleSpeak}
                        className="flex items-center gap-2 px-4 py-2 bg-green-500/20 text-green-400 rounded-lg hover:bg-green-500/30 transition-colors"
                      >
                        <Volume2 className="w-4 h-4" />
                        Listen
                      </motion.button>
                      
                      <motion.button
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        onClick={onShare}
                        className="flex items-center gap-2 px-4 py-2 bg-blue-500/20 text-blue-400 rounded-lg hover:bg-blue-500/30 transition-colors"
                      >
                        <Share2 className="w-4 h-4" />
                        Share
                      </motion.button>
                    </div>
                    
                    {/* Like Button and Auth Prompt */}
                    <div className="flex items-center justify-between pt-4 border-t border-gray-700">
                      <div className="flex items-center gap-2 text-gray-400">
                        <span className="text-sm">Rate this rizz:</span>
                      </div>
                      
                      {onFavorite ? (
                        <motion.button
                          whileHover={{ scale: 1.1 }}
                          whileTap={{ scale: 0.9 }}
                          onClick={handleLike}
                          className={`p-2 rounded-full transition-colors ${
                            liked ? 'bg-red-500/20 text-red-400' : 'bg-gray-700 text-gray-400 hover:bg-gray-600'
                          }`}
                        >
                          <Heart className={`w-5 h-5 ${liked ? 'fill-current' : ''}`} />
                        </motion.button>
                      ) : showAuthPrompt ? (
                        <div className="flex items-center gap-2">
                          <span className="text-gray-400 text-xs">Sign up to save favorites</span>
                          <UserPlus className="w-4 h-4 text-cyan-400" />
                        </div>
                      ) : (
                        <motion.button
                          whileHover={{ scale: 1.1 }}
                          whileTap={{ scale: 0.9 }}
                          className="p-2 rounded-full bg-gray-700 text-gray-400 hover:bg-gray-600 transition-colors"
                        >
                          <Heart className="w-5 h-5" />
                        </motion.button>
                      )}
                    </div>
                  </motion.div>
                )}
              </motion.div>
            ) : (
              <motion.div
                key="empty"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex items-center justify-center h-full text-gray-400"
              >
                <div className="text-center">
                  <div className="text-6xl mb-4">🚀</div>
                  <p>Select a vibe and describe your situation to get started!</p>
                  <p className="text-sm mt-2 text-gray-500">Your AI wingman is ready to help you shine ✨</p>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
};

export default RizzOutput;