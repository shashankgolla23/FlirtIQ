import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Heart, Zap, Smile, BookOpen, Sparkles, Target, Search } from 'lucide-react';

interface VibeSelectorProps {
  selectedVibe: string;
  onVibeChange: (vibe: string) => void;
}

const vibes = [
  { id: 'romantic', name: 'Romantic', icon: Heart, color: 'from-pink-500 to-rose-500', description: 'Sweet and heartfelt' },
  { id: 'savage', name: 'Savage', icon: Zap, color: 'from-red-500 to-orange-500', description: 'Bold and confident' },
  { id: 'funny', name: 'Funny', icon: Smile, color: 'from-yellow-500 to-amber-500', description: 'Witty and humorous' },
  { id: 'intellectual', name: 'Intellectual', icon: BookOpen, color: 'from-blue-500 to-indigo-500', description: 'Smart and sophisticated' },
  { id: 'mysterious', name: 'Mysterious', icon: Sparkles, color: 'from-purple-500 to-violet-500', description: 'Enigmatic and intriguing' },
  { id: 'direct', name: 'Direct', icon: Target, color: 'from-green-500 to-emerald-500', description: 'Straightforward and honest' },
];

const VibeSelector: React.FC<VibeSelectorProps> = ({ selectedVibe, onVibeChange }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [hoveredVibe, setHoveredVibe] = useState<string | null>(null);

  const filteredVibes = vibes.filter(vibe =>
    vibe.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    vibe.description.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="bg-glass-dark backdrop-blur-sm rounded-xl p-6 border border-cyan-500/30">
      <h3 className="text-xl font-semibold text-white mb-4">
        <Sparkles className="w-5 h-5 inline mr-2 text-cyan-400" />
        Pick Your Vibe
      </h3>
      
      {/* Search Bar */}
      <div className="relative mb-4">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
        <input
          type="text"
          placeholder="Search vibes..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full pl-10 pr-4 py-2 bg-black/30 border border-gray-700 rounded-lg text-white placeholder-gray-400 focus:border-cyan-500 focus:outline-none"
        />
      </div>

      {/* Vibe Grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
        {filteredVibes.map((vibe) => {
          const IconComponent = vibe.icon;
          return (
            <motion.button
              key={vibe.id}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => onVibeChange(vibe.id)}
              onMouseEnter={() => setHoveredVibe(vibe.id)}
              onMouseLeave={() => setHoveredVibe(null)}
              className={`relative p-4 rounded-xl border-2 transition-all duration-300 ${
                selectedVibe === vibe.id
                  ? 'border-cyan-500 bg-cyan-500/10'
                  : 'border-gray-700 hover:border-gray-600'
              }`}
            >
              <div className={`w-12 h-12 rounded-full bg-gradient-to-r ${vibe.color} flex items-center justify-center mx-auto mb-2`}>
                <IconComponent className="w-6 h-6 text-white" />
              </div>
              <h4 className="text-white font-medium text-sm">{vibe.name}</h4>
              
              <AnimatePresence>
                {hoveredVibe === vibe.id && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 10 }}
                    className="absolute -top-12 left-1/2 transform -translate-x-1/2 bg-black/90 text-white px-3 py-1 rounded-lg text-xs whitespace-nowrap z-10"
                  >
                    {vibe.description}
                    <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 translate-y-full w-0 h-0 border-l-4 border-r-4 border-t-4 border-transparent border-t-black/90"></div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.button>
          );
        })}
      </div>
      
      {filteredVibes.length === 0 && (
        <div className="text-center py-8 text-gray-400">
          No vibes found matching "{searchTerm}"
        </div>
      )}
    </div>
  );
};

export default VibeSelector;