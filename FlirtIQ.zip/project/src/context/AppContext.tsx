import React, { createContext, useContext, ReactNode, useState, useRef, useEffect } from 'react';

interface User {
  id: string;
  email: string;
  username: string;
  firstName?: string;
  lastName?: string;
  avatar?: string;
  stats: {
    rizzGenerated: number;
    favoriteLines: number;
    streak: number;
  };
  preferences: {
    soundEnabled: boolean;
    musicEnabled: boolean;
    autoCopy: boolean;
    theme: string;
  };
}

interface AppContextType {
  user: User | null;
  setUser: (user: User | null) => void;
  sendMessage: (message: string) => Promise<string>;
  soundEnabled: boolean;
  setSoundEnabled: (enabled: boolean) => void;
  musicEnabled: boolean;
  setMusicEnabled: (enabled: boolean) => void;
  autoCopy: boolean;
  setAutoCopy: (enabled: boolean) => void;
  theme: string;
  setTheme: (theme: string) => void;
  playInterstellarMusic: () => void;
  playPartyMusic: () => void;
  stopMusic: () => void;
  login: (token: string) => Promise<void>;
  logout: () => void;
  addFavorite: (rizz: string, vibe: string, avatar: string) => Promise<void>;
  removeFavorite: (favoriteId: string) => Promise<void>;
  updatePreferences: (preferences: Partial<User['preferences']>) => Promise<void>;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};

interface AppProviderProps {
  children: ReactNode;
}

export const AppProvider: React.FC<AppProviderProps> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [musicEnabled, setMusicEnabled] = useState(true);
  const [autoCopy, setAutoCopy] = useState(false);
  const [theme, setTheme] = useState('dark');
  const audioRef = useRef<HTMLAudioElement | null>(null);

  // Check for auth token on app load
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const token = urlParams.get('token');
    const authStatus = urlParams.get('auth');
    
    if (token && authStatus === 'success') {
      login(token);
      // Clean up URL
      window.history.replaceState({}, document.title, window.location.pathname);
    } else {
      // Check for stored token
      const storedToken = localStorage.getItem('flirtiq_token');
      if (storedToken) {
        login(storedToken);
      }
    }
  }, []);

  const getAuthHeaders = () => {
    const token = localStorage.getItem('flirtiq_token');
    return token ? { 'Authorization': `Bearer ${token}` } : {};
  };

  const login = async (token: string) => {
    try {
      localStorage.setItem('flirtiq_token', token);
      
      const response = await fetch('/auth/me', {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });
      
      if (response.ok) {
        const data = await response.json();
        console.log('User data received:', data.user); // Debug log
        setUser(data.user);
        
        // Update local settings from user preferences
        if (data.user.preferences) {
          setSoundEnabled(data.user.preferences.soundEnabled);
          setMusicEnabled(data.user.preferences.musicEnabled);
          setAutoCopy(data.user.preferences.autoCopy);
          setTheme(data.user.preferences.theme);
        }
      } else {
        console.error('Failed to fetch user data:', response.status);
        localStorage.removeItem('flirtiq_token');
      }
    } catch (error) {
      console.error('Login error:', error);
      localStorage.removeItem('flirtiq_token');
    }
  };

  const logout = async () => {
    try {
      await fetch('/auth/logout', {
        method: 'POST',
        headers: getAuthHeaders()
      });
    } catch (error) {
      console.error('Logout error:', error);
    } finally {
      localStorage.removeItem('flirtiq_token');
      setUser(null);
    }
  };

  const sendMessage = async (message: string): Promise<string> => {
    try {
      const response = await fetch('/api/chat/message', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...getAuthHeaders()
        },
        body: JSON.stringify({ 
          message,
          temperature: 0.8,
          max_tokens: 2048
        }),
      });
      
      const data = await response.json();
      return data.reply;
    } catch (error: any) {
      console.error('Error sending message:', error);
      
      // Fallback responses if API fails
      const fallbackResponses = [
        "I'm having a bit of trouble connecting right now, but I'm still here! 😊 What else would you like to chat about?",
        "Oops! Seems like there's a cosmic interference. Let me try to reconnect... In the meantime, tell me more about yourself! 🌟",
        "My circuits are a bit fuzzy right now, but I'm still your AI companion! What's on your mind? 💭",
        "Technical difficulties aside, I'm always here to chat! What would you like to talk about? ✨",
        "Even AI needs a moment sometimes! 😅 But I'm back now - what's your next question?"
      ];
      
      return fallbackResponses[Math.floor(Math.random() * fallbackResponses.length)];
    }
  };

  const addFavorite = async (rizz: string, vibe: string, avatar: string) => {
    if (!user) return;
    
    try {
      const response = await fetch('/auth/favorites', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...getAuthHeaders()
        },
        body: JSON.stringify({ rizz, vibe, avatar })
      });
      
      if (response.ok) {
        const data = await response.json();
        setUser(prev => prev ? { ...prev, stats: data.stats } : null);
      }
    } catch (error) {
      console.error('Add favorite error:', error);
    }
  };

  const removeFavorite = async (favoriteId: string) => {
    if (!user) return;
    
    try {
      const response = await fetch(`/auth/favorites/${favoriteId}`, {
        method: 'DELETE',
        headers: getAuthHeaders()
      });
      
      if (response.ok) {
        const data = await response.json();
        setUser(prev => prev ? { ...prev, stats: data.stats } : null);
      }
    } catch (error) {
      console.error('Remove favorite error:', error);
    }
  };

  const updatePreferences = async (preferences: Partial<User['preferences']>) => {
    if (!user) return;
    
    try {
      const response = await fetch('/auth/preferences', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          ...getAuthHeaders()
        },
        body: JSON.stringify(preferences)
      });
      
      if (response.ok) {
        const data = await response.json();
        setUser(prev => prev ? { ...prev, preferences: data.preferences } : null);
        
        // Update local state
        if (preferences.soundEnabled !== undefined) setSoundEnabled(preferences.soundEnabled);
        if (preferences.musicEnabled !== undefined) setMusicEnabled(preferences.musicEnabled);
        if (preferences.autoCopy !== undefined) setAutoCopy(preferences.autoCopy);
        if (preferences.theme !== undefined) setTheme(preferences.theme);
      }
    } catch (error) {
      console.error('Update preferences error:', error);
    }
  };

  const playInterstellarMusic = () => {
    if (!musicEnabled) return;
    
    if (audioRef.current) {
      audioRef.current.pause();
    }
    
    // Create new audio instance for interstellar music
    const audio = new Audio('/interstellar-theme.mp3');
    audio.volume = 0.3;
    audio.loop = true;
    audioRef.current = audio;
    
    audio.play().catch(error => {
      console.log('Audio autoplay prevented:', error);
    });
  };

  const playPartyMusic = () => {
    if (!musicEnabled) return;
    
    if (audioRef.current) {
      audioRef.current.pause();
    }
    
    // For now, we'll use a placeholder - you can add actual party music later
    console.log('Party music would play here');
  };

  const stopMusic = () => {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current = null;
    }
  };

  const value = {
    user,
    setUser,
    sendMessage,
    soundEnabled,
    setSoundEnabled,
    musicEnabled,
    setMusicEnabled,
    autoCopy,
    setAutoCopy,
    theme,
    setTheme,
    playInterstellarMusic,
    playPartyMusic,
    stopMusic,
    login,
    logout,
    addFavorite,
    removeFavorite,
    updatePreferences
  };

  return (
    <AppContext.Provider value={value}>
      {children}
    </AppContext.Provider>
  );
};