const express = require('express');
const passport = require('passport');
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const router = express.Router();

// Generate JWT token
const generateToken = (userId) => {
  return jwt.sign({ userId }, process.env.JWT_SECRET, { expiresIn: '7d' });
};

// Google OAuth routes
router.get('/google',
  passport.authenticate('google', { scope: ['profile', 'email'] })
);

router.get('/google/callback',
  passport.authenticate('google', { failureRedirect: `${process.env.FRONTEND_URL}?auth=failed` }),
  (req, res) => {
    // Successful authentication
    const token = generateToken(req.user._id);
    
    // Redirect to frontend with token
    res.redirect(`${process.env.FRONTEND_URL}?auth=success&token=${token}`);
  }
);

// Get current user
router.get('/me', passport.authenticate('jwt', { session: false }), async (req, res) => {
  try {
    const user = await User.findById(req.user._id).select('-googleId');
    res.json({
      success: true,
      user: {
        id: user._id,
        email: user.email,
        username: user.username,
        firstName: user.firstName,
        lastName: user.lastName,
        avatar: user.avatar,
        stats: user.stats,
        preferences: user.preferences
      }
    });
  } catch (error) {
    console.error('Get user error:', error);
    res.status(500).json({ success: false, error: 'Failed to get user data' });
  }
});

// Update user preferences
router.put('/preferences', passport.authenticate('jwt', { session: false }), async (req, res) => {
  try {
    const { soundEnabled, musicEnabled, autoCopy, theme } = req.body;
    
    const user = await User.findById(req.user._id);
    user.preferences = {
      soundEnabled: soundEnabled !== undefined ? soundEnabled : user.preferences.soundEnabled,
      musicEnabled: musicEnabled !== undefined ? musicEnabled : user.preferences.musicEnabled,
      autoCopy: autoCopy !== undefined ? autoCopy : user.preferences.autoCopy,
      theme: theme || user.preferences.theme
    };
    
    await user.save();
    
    res.json({
      success: true,
      preferences: user.preferences
    });
  } catch (error) {
    console.error('Update preferences error:', error);
    res.status(500).json({ success: false, error: 'Failed to update preferences' });
  }
});

// Add favorite rizz
router.post('/favorites', passport.authenticate('jwt', { session: false }), async (req, res) => {
  try {
    const { rizz, vibe, avatar } = req.body;
    
    if (!rizz || !vibe || !avatar) {
      return res.status(400).json({ success: false, error: 'Missing required fields' });
    }
    
    const user = await User.findById(req.user._id);
    await user.addFavorite({ rizz, vibe, avatar });
    
    res.json({
      success: true,
      message: 'Added to favorites',
      stats: user.stats
    });
  } catch (error) {
    console.error('Add favorite error:', error);
    res.status(500).json({ success: false, error: 'Failed to add favorite' });
  }
});

// Get user favorites
router.get('/favorites', passport.authenticate('jwt', { session: false }), async (req, res) => {
  try {
    const user = await User.findById(req.user._id);
    res.json({
      success: true,
      favorites: user.favorites
    });
  } catch (error) {
    console.error('Get favorites error:', error);
    res.status(500).json({ success: false, error: 'Failed to get favorites' });
  }
});

// Remove favorite rizz
router.delete('/favorites/:id', passport.authenticate('jwt', { session: false }), async (req, res) => {
  try {
    const user = await User.findById(req.user._id);
    await user.removeFavorite(req.params.id);
    
    res.json({
      success: true,
      message: 'Removed from favorites',
      stats: user.stats
    });
  } catch (error) {
    console.error('Remove favorite error:', error);
    res.status(500).json({ success: false, error: 'Failed to remove favorite' });
  }
});

// Logout
router.post('/logout', (req, res) => {
  req.logout((err) => {
    if (err) {
      return res.status(500).json({ success: false, error: 'Logout failed' });
    }
    res.json({ success: true, message: 'Logged out successfully' });
  });
});

module.exports = router;