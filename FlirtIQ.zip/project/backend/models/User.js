const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  googleId: {
    type: String,
    unique: true,
    sparse: true
  },
  email: {
    type: String,
    required: true,
    unique: true,
    lowercase: true
  },
  username: {
    type: String,
    required: true,
    unique: true,
    minlength: 3,
    maxlength: 30
  },
  firstName: {
    type: String,
    maxlength: 50
  },
  lastName: {
    type: String,
    maxlength: 50
  },
  avatar: {
    type: String
  },
  provider: {
    type: String,
    enum: ['google', 'local'],
    default: 'local'
  },
  stats: {
    rizzGenerated: {
      type: Number,
      default: 0
    },
    favoriteLines: {
      type: Number,
      default: 0
    },
    streak: {
      type: Number,
      default: 0
    },
    lastActive: {
      type: Date,
      default: Date.now
    }
  },
  favorites: [{
    rizz: String,
    vibe: String,
    avatar: String,
    createdAt: {
      type: Date,
      default: Date.now
    }
  }],
  preferences: {
    soundEnabled: {
      type: Boolean,
      default: true
    },
    musicEnabled: {
      type: Boolean,
      default: true
    },
    autoCopy: {
      type: Boolean,
      default: false
    },
    theme: {
      type: String,
      default: 'dark'
    }
  }
}, {
  timestamps: true
});

// Update streak logic
userSchema.methods.updateStreak = function() {
  const now = new Date();
  const lastActive = new Date(this.stats.lastActive);
  const daysDiff = Math.floor((now - lastActive) / (1000 * 60 * 60 * 24));
  
  if (daysDiff === 1) {
    // Consecutive day
    this.stats.streak += 1;
  } else if (daysDiff > 1) {
    // Streak broken
    this.stats.streak = 1;
  }
  // Same day, no change
  
  this.stats.lastActive = now;
  return this.save();
};

// Increment rizz generated count
userSchema.methods.incrementRizz = function() {
  this.stats.rizzGenerated += 1;
  return this.updateStreak();
};

// Add favorite rizz
userSchema.methods.addFavorite = function(rizzData) {
  this.favorites.push(rizzData);
  this.stats.favoriteLines = this.favorites.length;
  return this.save();
};

// Remove favorite rizz
userSchema.methods.removeFavorite = function(favoriteId) {
  this.favorites.id(favoriteId).remove();
  this.stats.favoriteLines = this.favorites.length;
  return this.save();
};

module.exports = mongoose.model('User', userSchema);