# FlirtIQ Backend

Backend API for FlirtIQ - AI Conversation Companion

## Features

- 🤖 OpenAI GPT-4 integration for intelligent conversations
- 💬 Real-time chat API
- 🛡️ Rate limiting and security headers
- 🌐 CORS configuration for frontend integration

## Setup

### Prerequisites

- Node.js 18+
- OpenAI API key

### Installation

1. Navigate to backend directory:
   ```bash
   cd backend
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Configure environment variables:
   ```bash
   cp .env.example .env
   ```

4. Update your `.env` file with:
   - OpenAI API key
   - Other configuration values

5. Start the development server:
   ```bash
   npm run dev
   ```

## API Endpoints

### Chat
- `POST /api/chat/message` - Send message to AI

### Health Check
- `GET /api/health` - Server health status

## Environment Variables

```env
OPENAI_API_KEY=your_openai_api_key
PORT=3001
NODE_ENV=development
FRONTEND_URL=http://localhost:5173
```

## Deployment

### Heroku
```bash
heroku create flirtiq-backend
heroku config:set OPENAI_API_KEY=your_key
git push heroku main
```

### Railway/Render
1. Connect GitHub repository
2. Set environment variables
3. Deploy automatically

## Security Features

- Helmet.js for security headers
- Rate limiting (100 requests per 15 minutes)
- Input validation
- CORS protection

## License

MIT License - Built by Shashank ✨