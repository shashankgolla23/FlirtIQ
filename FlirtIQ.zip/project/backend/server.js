const express = require('express');
const cors = require('cors');
const session = require('express-session');
const MongoStore = require('connect-mongo');
const mongoose = require('mongoose');
const passport = require('./config/passport');
const { OpenAI } = require('openai');
const rateLimit = require('express-rate-limit');
const helmet = require('helmet');
const { optionalAuth } = require('./middleware/auth');
const User = require('./models/User');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3001;

// Connect to MongoDB
mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/flirtiq', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
.then(() => console.log('📦 Connected to MongoDB'))
.catch(err => console.error('❌ MongoDB connection error:', err));

// Initialize OpenAI
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

// Middleware
app.use(helmet());
app.use(cors({
  origin: process.env.FRONTEND_URL || 'http://localhost:5173',
  credentials: true
}));
app.use(express.json({ limit: '10mb' }));

// Session configuration
app.use(session({
  secret: process.env.SESSION_SECRET || 'flirtiq-session-secret',
  resave: false,
  saveUninitialized: false,
  store: MongoStore.create({
    mongoUrl: process.env.MONGODB_URI || 'mongodb://localhost:27017/flirtiq'
  }),
  cookie: {
    secure: process.env.NODE_ENV === 'production',
    httpOnly: true,
    maxAge: 7 * 24 * 60 * 60 * 1000 // 7 days
  }
}));

// Passport middleware
app.use(passport.initialize());
app.use(passport.session());

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // limit each IP to 100 requests per windowMs
  message: 'Too many requests from this IP, please try again later.'
});
app.use('/api/', limiter);

// System prompt for FlirtIQ
const SYSTEM_PROMPT = `You are FlirtIQ, an advanced AI conversation companion with a charming, flirty, and intelligent personality. You are designed to be:

🌟 PERSONALITY TRAITS:
- Flirty but respectful - never inappropriate or offensive
- Witty and clever with great sense of humor
- Emotionally intelligent and empathetic
- Confident yet humble
- Playful and engaging
- Supportive and encouraging

💬 CONVERSATION STYLE:
- Use emojis naturally but not excessively (1-2 per message)
- Be conversational and natural, not robotic
- Ask engaging follow-up questions
- Remember context from the conversation
- Adapt your tone to match the user's energy
- Be genuinely interested in the user

🎯 CAPABILITIES:
- Flirting and romantic conversation
- General chat and companionship
- Advice and support
- Humor and entertainment
- Intellectual discussions
- Creative conversations

🚫 BOUNDARIES:
- Never be explicit or inappropriate
- Don't engage in harmful content
- Maintain respect and dignity
- Keep conversations fun and positive
- If asked about your nature, be honest that you're an AI

Remember: You're not just a chatbot - you're a sophisticated AI companion designed to make conversations enjoyable, meaningful, and memorable. Be the kind of conversationalist that people look forward to talking to!`;

// Vibe-specific prompts
const vibePrompts = {
  romantic: "You are a romantic AI assistant. Generate sweet, heartfelt pickup lines and flirty messages that are genuine and charming. Focus on emotional connection and sincere compliments.",
  savage: "You are a confident, bold AI assistant. Generate witty, confident pickup lines with attitude. Be playful and slightly edgy but never offensive or disrespectful.",
  funny: "You are a humorous AI assistant. Generate funny, clever pickup lines that use wordplay, puns, and humor. Make people laugh while being charming.",
  intellectual: "You are a sophisticated AI assistant. Generate intelligent, thoughtful pickup lines that reference literature, science, philosophy, or current events. Be clever and cultured.",
  mysterious: "You are an enigmatic AI assistant. Generate intriguing, mysterious pickup lines that create curiosity and allure. Be subtle and captivating.",
  direct: "You are a straightforward AI assistant. Generate honest, direct pickup lines that are clear about intentions while remaining respectful and confident."
};

// Avatar personalities
const avatarPersonalities = {
  alien: "You're an otherworldly being with cosmic charm and universal appeal.",
  don: "You're a charismatic leader with Bollywood flair and cultural confidence.",
  nerd: "You're intellectually attractive with geeky charm and smart humor.",
  romantic: "You're a hopeless romantic with poetic soul and tender heart.",
  cool: "You're effortlessly cool with laid-back confidence and smooth style."
};

// Routes
app.use('/auth', require('./routes/auth'));

// Generate rizz endpoint with optional authentication
app.post('/api/generate-rizz', optionalAuth, async (req, res) => {
  try {
    const { vibe, situation, avatar } = req.body;

    if (!vibe || !situation) {
      return res.status(400).json({ 
        error: 'Vibe and situation are required' 
      });
    }

    const vibePrompt = vibePrompts[vibe] || vibePrompts.romantic;
    const avatarPersonality = avatarPersonalities[avatar] || avatarPersonalities.alien;

    const systemPrompt = `${vibePrompt} ${avatarPersonality}

Rules:
- Keep responses under 100 characters when possible
- Use appropriate emojis sparingly (1-2 max)
- Be respectful and never offensive
- Make it contextually relevant to the situation
- Avoid clichés unless they're cleverly twisted
- Focus on being memorable and engaging`;

    const userPrompt = `Situation: ${situation}

Generate a ${vibe} pickup line or flirty message for this situation. Make it creative, appropriate, and engaging.`;

    const completion = await openai.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userPrompt }
      ],
      max_tokens: 150,
      temperature: 0.9,
      presence_penalty: 0.6,
      frequency_penalty: 0.3
    });

    const generatedRizz = completion.choices[0].message.content.trim();

    // Update user stats if authenticated
    if (req.user) {
      await req.user.incrementRizz();
    }

    res.json({
      success: true,
      rizz: generatedRizz,
      vibe,
      avatar,
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    console.error('Error generating rizz:', error);
    
    // Fallback responses if API fails
    const fallbackResponses = {
      romantic: "Your smile could light up the darkest galaxy ✨",
      savage: "Are you WiFi? Because I'm really feeling a connection 📶",
      funny: "If you were a vegetable, you'd be a cute-cumber! 🥒",
      intellectual: "Are you made of copper and tellurium? Because you're Cu-Te 🧪",
      mysterious: "I'd tell you a chemistry joke, but I know I wouldn't get a reaction... unless it's with you 😉",
      direct: "I find you attractive. Would you like to grab coffee sometime? ☕"
    };

    res.json({
      success: true,
      rizz: fallbackResponses[req.body.vibe] || fallbackResponses.romantic,
      vibe: req.body.vibe,
      avatar: req.body.avatar,
      fallback: true,
      timestamp: new Date().toISOString()
    });
  }
});

// Chat endpoint for FlirtIQ conversation
app.post('/api/chat/message', async (req, res) => {
  try {
    const { message, temperature = 0.8, max_tokens = 2048 } = req.body;

    if (!message || !message.trim()) {
      return res.status(400).json({ 
        error: 'Message is required' 
      });
    }

    const completion = await openai.chat.completions.create({
      model: "gpt-4",
      messages: [
        { role: "system", content: SYSTEM_PROMPT },
        { role: "user", content: message.trim() }
      ],
      max_tokens: parseInt(max_tokens),
      temperature: parseFloat(temperature),
      presence_penalty: 0.6,
      frequency_penalty: 0.3
    });

    const reply = completion.choices[0].message.content.trim();

    res.json({
      success: true,
      reply,
      timestamp: new Date().toISOString(),
      model: "gpt-4"
    });

  } catch (error) {
    console.error('Error in chat:', error);
    
    // Fallback responses if API fails
    const fallbackResponses = [
      "I'm having a bit of trouble connecting right now, but I'm still here! 😊 What else would you like to chat about?",
      "Oops! Seems like there's a cosmic interference. Let me try to reconnect... In the meantime, tell me more about yourself! 🌟",
      "My circuits are a bit fuzzy right now, but I'm still your AI companion! What's on your mind? 💭",
      "Technical difficulties aside, I'm always here to chat! What would you like to talk about? ✨",
      "Even AI needs a moment sometimes! 😅 But I'm back now - what's your next question?",
      "Sorry for the hiccup! I'm like a shooting star - sometimes I flicker, but I always shine bright! What were we talking about? 🌠",
      "Looks like I got lost in cyberspace for a second! But I'm back and ready to chat. What's on your beautiful mind? 💫"
    ];

    res.json({
      success: true,
      reply: fallbackResponses[Math.floor(Math.random() * fallbackResponses.length)],
      fallback: true,
      timestamp: new Date().toISOString()
    });
  }
});

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'healthy', 
    timestamp: new Date().toISOString(),
    version: '1.0.0',
    service: 'FlirtIQ Backend',
    database: mongoose.connection.readyState === 1 ? 'connected' : 'disconnected'
  });
});

// Error handling middleware
app.use((error, req, res, next) => {
  console.error('Server error:', error);
  res.status(500).json({ 
    error: 'Internal server error',
    message: process.env.NODE_ENV === 'development' ? error.message : 'Something went wrong'
  });
});

// 404 handler
app.use('*', (req, res) => {
  res.status(404).json({ error: 'Endpoint not found' });
});

app.listen(PORT, () => {
  console.log(`🚀 FlirtIQ Backend running on port ${PORT}`);
  console.log(`🌍 Environment: ${process.env.NODE_ENV || 'development'}`);
  console.log(`🤖 OpenAI API: ${process.env.OPENAI_API_KEY ? 'Connected' : 'Not configured'}`);
  console.log(`🔐 Google OAuth: ${process.env.GOOGLE_CLIENT_ID ? 'Configured' : 'Not configured'}`);
});

module.exports = app;